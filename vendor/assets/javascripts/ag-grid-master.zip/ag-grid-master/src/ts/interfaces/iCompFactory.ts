import {Component} from "../widgets/component";

export interface ICompFactory {

    create(): Component;

}
